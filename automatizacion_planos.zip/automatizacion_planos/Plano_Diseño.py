import os
import processing
from qgis.core import QgsField, QgsProject, QgsVectorLayer, QgsLayoutExporter, QgsPoint, QgsVectorFileWriter, QgsProcessingFeatureSourceDefinition, QgsFeatureSource, QgsFeatureRequest, QgsRectangle
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.utils import iface


### PREPARACION DE CAPAS

ruta = QgsProject.instance().readPath("./")
projectInstance = QgsProject.instance()
layoutmanager = projectInstance.layoutManager()
layout_ls = layoutmanager.layoutByName("Plano_Diseño_landscape")
layout_pt = layoutmanager.layoutByName("Plano_Diseño_portrait")
map_ls = layout_ls.referenceMap()
map_pt = layout_pt.referenceMap()

mapcanvas = iface.mapCanvas()

pantes = mapcanvas.layer(2)
lotes = mapcanvas.layer(1)
linderos = mapcanvas.layer(0)

### SELECCION DE LINDEROS

selec_linderos_0 = linderos.materialize(QgsFeatureRequest().setFilterFids(linderos.selectedFeatureIds()))
linderos.removeSelection()

area_lote = 0
for ff in selec_linderos_0.getFeatures():
    n_finca = ff['FINCA']
    id_finca = ff['ID_FINCA'] 
    area_finca = ff['shape_area']/10000
    r_finca = ff['REGION']
    selec_linderos_0.select(ff.id())
    selec_linderos = selec_linderos_0.materialize(QgsFeatureRequest().setFilterFids(selec_linderos_0.selectedFeatureIds()))
    
    parameters = {'INPUT' : lotes,
        'INTERSECT' : selec_linderos,
        'METHOD' : 0,
        'PREDICATE' : [0],
        'OUTPUT' : 'TEMPORARY_OUTPUT' }
    temp0 = processing.run('qgis:selectbylocation', parameters)

    parameters = {'INPUT' : pantes,
        'INTERSECT' : selec_linderos,
        'METHOD' : 0,
        'PREDICATE' : [0],
        'OUTPUT' : 'TEMPORARY_OUTPUT' }
    temp1 = processing.run('qgis:selectbylocation', parameters)

    selec_lotes = temp0 ['OUTPUT'].materialize(QgsFeatureRequest().setFilterFids(temp0 ['OUTPUT'].selectedFeatureIds()))
    selec_pantes = temp1 ['OUTPUT'].materialize(QgsFeatureRequest().setFilterFids(temp1 ['OUTPUT'].selectedFeatureIds()))

    selec_linderos_0.removeSelection()
    lotes.removeSelection()
    pantes.removeSelection()

    selec_lotes.startEditing()
    selec_lotes.dataProvider().addAttributes([QgsField("area_ha", QVariant.Double)])
    selec_lotes.updateFields()
    id_new_col= selec_lotes.dataProvider().fieldNameIndex("area_ha")

    area_siembra_finca = 0
    print(n_finca)
    selec_lotes.selectByExpression(" \"ID_FINCA\" = '{}' ".format(id_finca))
    for fl in selec_lotes.selectedFeatures():
        n_lote = fl['ABS_LOTE']
        id_lotefinca = fl['ABS_IDCOMP']
        area_lote = 0
        selec_pantes.selectByExpression(" \"ABS_IDCOMP\" = '{}' ".format(id_lotefinca))
        for fp in selec_pantes.selectedFeatures():
            area_pante = fp['HA']
            area_lote = area_pante + area_lote
        selec_pantes.removeSelection()
        selec_lotes.changeAttributeValue(fl.id(), id_new_col, area_lote)
        area_siembra_finca = area_lote + area_siembra_finca
    selec_lotes.removeSelection()

    root = QgsProject.instance().layerTreeRoot()
    selec_linderos.loadNamedStyle(ruta + '/estilo_linderos.qml')
    selec_linderos.setName('Linderos seleccionados')
    QgsProject.instance().addMapLayer(selec_linderos)
    selec_lotes.loadNamedStyle(ruta + '/estilo_lotes.qml')
    selec_lotes.setName('Lotes seleccionados')
    QgsProject.instance().addMapLayer(selec_lotes)
    selec_pantes.loadNamedStyle(ruta + '/estilo_pantes.qml')
    selec_pantes.setName('Pantes seleccionados')
    QgsProject.instance().addMapLayer(selec_pantes)

### PRODUCCION DE PLANOS

    box = ff.geometry().boundingBox()
    xmin,ymin,xmax,ymax = box.toRectF().getCoords()
    box1 = QgsRectangle(xmin -20,ymin -20,xmax +20,ymax +20)
    mapcanvas.setExtent(box)


### EXPORTACION DE PLANO

    if xmax-xmin > ymax-ymin:
        layout = layout_ls
        map = map_ls

    else:
        layout = layout_pt
        map = map_pt

### SELECCION DE ESPACIADO DE GRID

    map.grid().setEnabled(True)
    if xmax-xmin <= 200:
        map.grid().setIntervalX(50)
        map.grid().setIntervalY(50)
    if xmax-xmin > 200 and xmax-xmin <= 500:
        map.grid().setIntervalX(100)
        map.grid().setIntervalY(100)
    if xmax-xmin > 500 and xmax-xmin <= 1000:
        map.grid().setIntervalX(200)
        map.grid().setIntervalY(200)
    if xmax-xmin > 1000 and xmax-xmin <= 2500:
        map.grid().setIntervalX(500)
        map.grid().setIntervalY(500)
    if xmax-xmin > 2500:
        map.grid().setIntervalX(1000)
        map.grid().setIntervalY(1000)

### ETIQUETADO
        
    label = layout.itemById('CODIGO')
    label.setText(id_finca)
    label = layout.itemById('NOMBRE')
    label.setText(n_finca)
    label = layout.itemById('AREA_SIEM')
    label.setText(str(round(area_siembra_finca,2))+ ' ha')
    label = layout.itemById('REGION')
    label.setText(r_finca)


    map.zoomToExtent(box1)
    exporter = QgsLayoutExporter(layout)
    exporter.exportToPdf(ruta + "/PLANOS/" + n_finca + ".pdf", QgsLayoutExporter.PdfExportSettings() )

    selec_lotes.commitChanges()

    root.removeLayer(selec_linderos)
    root.removeLayer(selec_lotes)
    root.removeLayer(selec_pantes)

QMessageBox.information(iface.mainWindow(), "Finalizado", 'Los PLANOS ha sido guardado en la carpeta: '+ruta+"/PLANOS/")
