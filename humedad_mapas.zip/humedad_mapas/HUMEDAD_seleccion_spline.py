import os
import processing
from PyQt5.QtWidgets import QFileDialog, QLineEdit, QInputDialog, QMessageBox
from qgis.core import QgsProject, QgsVectorLayer, QgsLayoutExporter, QgsPoint, QgsVectorFileWriter, QgsProcessingFeatureSourceDefinition, QgsFeatureSource, QgsFeatureRequest, QgsRectangle
from qgis.utils import iface


ruta = QgsProject.instance().readPath("./")
projectInstance = QgsProject.instance()
layoutmanager = projectInstance.layoutManager()
layout = layoutmanager.layoutByName("Mapa_Humedad")
map = layout.referenceMap()

mapcanvas = iface.mapCanvas()
layer = mapcanvas.layer(0)
lotes = mapcanvas.layer(1)
supervisoridx=layer.dataProvider().fieldNameIndex('supervisor')
uniquevalues=layer.uniqueValues(supervisoridx)

## ENTRADA DE INFORMACION

fields = layer.fields()

qid = QInputDialog()
title = "Semana de Muestreo"
label = "Semana:" 
mode = QLineEdit.Normal
semana, ok = QInputDialog.getText(qid, title, label, mode)

qid = QInputDialog()
title = "Campo para Interpolar"
label = "Campo" 
mode = QLineEdit.Normal
campo, ok = QInputDialog.getItem(qid, title, label, fields.names(), 0, False)
field_index = layer.fields().indexFromName(campo)


## INICIA PROCESO

for uv in uniquevalues:
    print (uv)

    if uv != None:
        layer.selectByExpression(" \"supervisor\" = '{}' ".format(uv))
    else:
        layer.selectByExpression(' \"supervisor\" is NULL ')
    
    
    parameters = {'INPUT' : lotes,
            'INTERSECT' : QgsProcessingFeatureSourceDefinition(layer.source(), True),
            'METHOD' : 0,
            'PREDICATE' : [0],
            'OUTPUT' : 'TEMPORARY_OUTPUT' }
    temp0 = processing.run('qgis:selectbylocation', parameters)
    
    box = lotes.boundingBoxOfSelected()
    xmin,ymin,xmax,ymax = box.toRectF().getCoords()
    box1 = QgsRectangle(xmin - 20,ymin - 20,xmax + 20,ymax + 20)
    mapcanvas.setExtent(box)

    #   PROCESO DE INTERPOLACION
    
    selection = layer.materialize(QgsFeatureRequest().setFilterFids(layer.selectedFeatureIds()))
    vlayer = selection.name() + "::~::0::~::"+str(field_index)+"::~::0"
    ext = str(xmin) + ', ' + str(xmax) + ', ' + str(ymin) + ', ' + str(ymax) + ' [EPSG:32616]'
    
    parameters = {'SHAPES' : QgsProcessingFeatureSourceDefinition(layer.source(), True),
            'FIELD' : campo,
            'LEVEL' : 9,
            'TARGET_USER_SIZE' : 50,
            'TARGET_USER_XMIN TARGET_USER_XMAX TARGET_USER_YMIN TARGET_USER_YMAX' : ext,
            'TARGET_USER_FITS' : 1,
            'TARGET_OUT_GRID' : 'TEMPORARY_OUTPUT' }
    temp = processing.run('saga:bsplineapproximation', parameters)

#    parameters = {'INTERPOLATION_DATA' : vlayer,
#            'DISTANCE_COEFFICIENT' : 2.8,
#            'EXTENT' : ext,
#            'PIXEL_SIZE' : 100,
#            'OUTPUT' : 'TEMPORARY_OUTPUT' }
#    temp = processing.run('qgis:idwinterpolation', parameters)

    parameters = {'INPUT' : temp ['TARGET_OUT_GRID'],
            'RESAMPLING':1,
            'TARGET_RESOLUTION' : 10,
            'OUTPUT' : 'TEMPORARY_OUTPUT' }
    temp1 = processing.run('gdal:warpreproject', parameters)

    parameters = {'INPUT_RASTER' : temp1 ['OUTPUT'],
            'DATA_TYPE' : 5,
            'RASTER_BAND' : 1,
            'TABLE' : [0,1.5,1,1.5,2.5,2,2.5,3.5,3,3.5,6,4],
            'NODATA_FOR_MISSING' : False,
            'NO_DATA' : -9999,
            'OUTPUT' : 'TEMPORARY_OUTPUT' }
    temp2 = processing.run('qgis:reclassifybytable', parameters)

    parameters = {'INPUT' : temp2 ['OUTPUT'],
            'BAND':1,
            'EIGHT_CONNECTEDNESS' : False,
            'FIELD' : 'Rango',
            'OUTPUT' : 'TEMPORARY_OUTPUT' }
    temp3 = processing.run('gdal:polygonize', parameters)

    parameters = { 'INPUT' : temp3 ['OUTPUT'],
            'MASK' : QgsProcessingFeatureSourceDefinition(lotes.source(), True),
            'OUTPUT' : 'TEMPORARY_OUTPUT' }
    temp4 = processing.run('gdal:clipvectorbypolygon', parameters)
    
    parameters = {'INPUT': temp4 ['OUTPUT'],
            'GEOMETRY' : 'geometry',
            'FIELD': 'Rango',
            'COMPUTE_AREA' : True,
            'OUTPUT': 'TEMPORARY_OUTPUT' }
    temp5 = processing.run('gdal:dissolve', parameters)

    #    PRODUCCION DE MAPAS

    root = QgsProject.instance().layerTreeRoot()

    layer1 = QgsVectorLayer(temp5 ['OUTPUT'], "Humedad", "ogr")
    layer1.loadNamedStyle(ruta + '/estilo.qml')
    root.insertLayer(2, layer1)

    if uv != None:
        nombre = uv
    else:
        nombre = 'NULL'

    label = layout.itemById('supervisor')
    label.setText(nombre)
    label = layout.itemById('semana')
    label.setText(semana)

    map.zoomToExtent(box1)
    exporter = QgsLayoutExporter(layout)
    exporter.exportToPdf(ruta + "/MAPAS/" + 'Semana_'+ semana +'_'+ nombre + ".pdf", QgsLayoutExporter.PdfExportSettings() )
 
    root.removeLayer(layer1)
 
    layer.removeSelection()
    lotes.removeSelection()

QMessageBox.information(iface.mainWindow(), "Finalizado", 'Los mapas han sido guardados en la carpeta: '+ruta+"/MAPAS/")
