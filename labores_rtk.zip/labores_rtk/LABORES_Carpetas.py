import os
import processing
from PyQt5.QtWidgets import QFileDialog, QLineEdit, QInputDialog, QMessageBox
from qgis.core import QgsProject, QgsVectorLayer, QgsLayoutExporter, QgsPoint, QgsVectorFileWriter, QgsProcessingFeatureSourceDefinition
from qgis.utils import iface

qfd = QFileDialog()
title = "Seleccion de Carpeta con Coverages"
path = QFileDialog.getExistingDirectory(qfd, title)

qid = QInputDialog()
items = ("211   Subsuelo             4.0" ,
        "221    Grada-Pesada    4.1 ",
        "226    Arado-Cincel      3.15",
        "231    Rastra-Liviana    3.2",
        "231    Rastra-Liviana    4.8",
        "239    Canterizado        3.5",
        "241    Surcado              3.5",
        "241    Surcado              4.8",
        "241    Surcado              5.25",
        "324    Siembra              1.75")

title = "Tipo de la labor"
label = "Codigo  Labor          Ancho(m):" 
mode = QLineEdit.Normal
labor, ok = QInputDialog.getItem(qid, title, label, items, 0, False)

list_labor = labor.split()
labor_codigo = list_labor[0]
labor_nombre = list_labor[1]
ancho = list_labor[2]

print("Ancho: "+ str(ancho))

for file in os.listdir(path):
    if file.endswith(".shp"):
        print(path, file)
        layer = None
        layer = QgsVectorLayer(path+'/'+file, "Coverage", "ogr")
        QgsProject.instance().addMapLayer(layer)
        
        ##PROCESO DE CALCULO DE PASADAS DE SURCADO Y ANGULO

        mapcanvas = iface.mapCanvas()
        ruta = QgsProject.instance().readPath("./")

        parameters = {'INPUT': layer,
                    'OUTPUT' : 'memory:' }
        temp = processing.run('qgis:fixgeometries', parameters)

        parameters = {'INPUT': temp ['OUTPUT'],
                    'OUTPUT' : 'memory:' }
        temp0 = processing.run('qgis:deleteduplicategeometries', parameters)

        parameters = {'INPUT': temp0 ['OUTPUT'],
                    'ALL_PARTS' : False,
                    'OUTPUT' : 'memory:'}
        temp1 = processing.run('qgis:centroids', parameters)

        def def_name(f0):
            return f0['TimeClosed']
        features0 = sorted(temp1 ['OUTPUT'].getFeatures(),key = def_name)
        
        def def_name(f):
            return f['DateClosed']
        features = sorted(features0, key = def_name)

        i = 0
        k = 0
        x = 0
        angulo = 0
        point = {}
        ang = {}
        for feat in features:
            i = i + 1
            point[i] = feat.geometry().asPoint()
            if(i > 1):
                ang[i] = QgsPoint(point[i]).azimuth(QgsPoint(point[i-1]))
#                print (ang[i])
                if ( i > 5):
                    if (abs(ang[i] - ang[i-1]) < 5):
                        x = x + 1
                        if (x > 6):
                            x0 = 1
                            angulo = (ang[i-1] + ang[i-2] + ang[i-3]) / 3
                    else:
                        if (x0 == 1):
                            k = k + 1
                            x0 = 0
                            x = 0
        print('Pases:' + str(k))
        print('Angulo:'+ str(angulo))

        ##PROCESO DE CALCULO DE PASADAS TEORICO

        mapcanvas = iface.mapCanvas()
        maestrolotes = mapcanvas.layer(0)
        ruta = QgsProject.instance().readPath("./")
        lote_select = ruta + "/PROCESO/lote.shp"
        lote_ext = ruta + "/PROCESO/lote_ext.shp"
        lote_rot = ruta + "/PROCESO/lote_rot.shp"
        grid = ruta + "/PROCESO/grid.shp"
        surcado = ruta + "/PROCESO/surcado.shp"
        grid_rot = ruta + "/PROCESO/grid_rot.shp"
        grid_fin = ruta + "/PROCESO/grid_fin.shp"
        grid_layer = None

        #SELECCIONAR El LOTE

        maestrolotes.removeSelection()

        parameters = {'INPUT': maestrolotes,
                    'INTERSECT' : temp ['OUTPUT'],
                    'METHOD' : 0,
                    'PREDICATE' : [1],
                    'OUTPUT' : 'memory:' }
        temp2 = processing.run('qgis:selectbylocation', parameters)
        
        writer = QgsVectorFileWriter.writeAsVectorFormat(maestrolotes, lote_select, "utf-8", maestrolotes.crs(), 'ESRI Shapefile', onlySelected=True)
        del writer
        lote_select_layer = QgsVectorLayer(lote_select, '', 'ogr' )
        
        #maestrolotes.removeSelection()

        #lote = None
        #lote = QgsVectorLayer(lote_select, '', 'ogr' )
        features = maestrolotes.selectedFeatures()

        for feat in features:
            nlote = feat["NOMBRE"]
            codigo = feat["LOTE"]
            area = round(feat["Area_ha"],2)

        print("Nombre: " + nlote)
        print("Codigo: " + codigo)

        #Define extent of Polygon
        ext = maestrolotes.boundingBoxOfSelected()
        xmin = ext.xMinimum()
        xmax = ext.xMaximum()
        ymin = ext.yMinimum()
        ymax = ext.yMaximum()
        coords = "%f,%f,%f,%f" %(xmin, xmax, ymin, ymax)

        
        #Define The angle of rotation. Change value to yours
        azimut = angulo

        xcent = xmin + ((xmax - xmin) / 2)
        ycent = ymin + ((ymax - ymin) / 2)

        #define anchor point for rotation
        anchor = "%f, %f" % (xcent, ycent)

        #define x and y spacing of grid. Update to your desired spacing.

        #create new polygon from extent

        parameters = {'INPUT': coords ,
            'OUTPUT' : 'memory:' }
        temp4 = processing.run('qgis:extenttolayer', parameters)

        #writer = QgsVectorFileWriter.writeAsVectorFormat(temp4 ['OUTPUT'], lote_ext, "utf-8", temp4 ['OUTPUT'].crs(), 'ESRI Shapefile', onlySelected=False)
        #del writer

        #Rotate Extent

        #lote_ext_layer = None
        #lote_ext_layer = QgsVectorLayer(lote_ext, '', 'ogr' )

        parameters = {'INPUT': temp4 ['OUTPUT'],
                    'ANGLE': azimut,
                    'ANCHOR':anchor,
                    'OUTPUT' : 'memory:'}
        temp5 = processing.run('qgis:rotatefeatures', parameters)

        #writer = QgsVectorFileWriter.writeAsVectorFormat(temp5 ['OUTPUT'], lote_rot, "utf-8", temp5 ['OUTPUT'].crs(), 'ESRI Shapefile', bool(True))
        #del writer

        #Define extent of Rotated Polygon

        #lote_rot_layer = None
        #lote_rot_layer = QgsVectorLayer(lote_rot, '', 'ogr' )

        ext1 = temp5 ['OUTPUT'].extent()
        xmin1 = ext1.xMinimum()
        xmax1 = ext1.xMaximum()
        ymin1 = ext1.yMinimum()
        ymax1 = ext1.yMaximum()
        coords1 = "%f,%f,%f,%f" %(xmin1, xmax1, ymin1, ymax1)

        x = ancho
        y = int(ymax1 - ymin1)

        #Create grid 
        temp6 = processing.run("qgis:creategrid", {'TYPE':2,'EXTENT': coords1,'HSPACING':x,'VSPACING':y,'HOVERLAY':0,'VOVERLAY':0,'CRS':'EPSG:32616','OUTPUT': 'memory:'})

        writer1 = QgsVectorFileWriter.writeAsVectorFormat(temp6 ['OUTPUT'], grid, "utf-8", temp6 ['OUTPUT'].crs(), 'ESRI Shapefile', onlySelected=False)
        del writer1

        #Rotate Grid to original extent
        temp7 = processing.run("qgis:rotatefeatures", {'INPUT': temp6 ['OUTPUT'],'ANGLE': azimut, 'ANCHOR': anchor,'OUTPUT': 'memory:'})

        # Clip Grid to Original Polygon
        parameters = {'INPUT': temp7 ['OUTPUT'],
                    'OVERLAY': QgsProcessingFeatureSourceDefinition(maestrolotes.source(), True),
                    'OUTPUT' : 'memory:'}
        temp8 = processing.run('qgis:clip', parameters)
        
        writer2 = QgsVectorFileWriter.writeAsVectorFormat(temp8 ['OUTPUT'], grid_fin, "utf-8", temp8 ['OUTPUT'].crs(), 'ESRI Shapefile', onlySelected=False)
        del writer2

        #grid_layer = QgsVectorLayer(grid_fin, '', 'ogr' )
        features = temp8 ['OUTPUT'].getFeatures()
        i = 0
        for feat in features:
            i = i + 1

        pases_0 = str(i)

        print ('Teorico: '+ pases_0)

        efic = round(((k / i) * 100), 1)
        print ('Eficiencia: ' + str(efic))

        # COMPOSICION DE MAPA

        projectInstance = QgsProject.instance()
        layoutmanager = projectInstance.layoutManager()
        layout = layoutmanager.layoutByName("Mapa")
        map = layout.referenceMap()

        label = layout.itemById('nombre')
        label.setText(nlote)
        label = layout.itemById('lote')
        label.setText(codigo)
        label = layout.itemById('area')
        label.setText(str(area)+ ' ha')
        label = layout.itemById('labor')
        label.setText(str(labor_nombre))
        label = layout.itemById('pases')
        label.setText(str(k))
        label = layout.itemById('pases_0')
        label.setText(str(i))
        label = layout.itemById('eficiencia')
        label.setText(str(efic) + ' %')

        map.zoomToExtent(ext1)

        exporter = QgsLayoutExporter(layout)
        exporter.exportToPdf(ruta + "/MAPAS/" + labor_codigo + '_' + nlote + "_" + codigo + ".pdf", QgsLayoutExporter.PdfExportSettings() )

        temp ['OUTPUT'] = None
        temp0 ['OUTPUT'] = None
        temp1 ['OUTPUT'] = None
        temp2 ['OUTPUT'] = None
        temp4 ['OUTPUT'] = None
        temp5 ['OUTPUT'] = None
        temp6 ['OUTPUT'] = None
        temp7 ['OUTPUT'] = None
        temp8 ['OUTPUT'] = None
        
        QgsProject.instance().removeMapLayer(layer)
        layer = None
        maestrolotes.removeSelection()
        lote_select_layer = None

QMessageBox.information(iface.mainWindow(), "Finalizado", 'Los mapas han sido guardados en la carpeta: '+ruta+"/MAPAS/")