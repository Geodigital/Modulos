import os
import sys
import processing
from qgis.core import *
from qgis.PyQt.QtCore import QVariant
from qgis.utils import iface


#drift = 'C:/temp/AirLog_CASUR/DATA/Drift.shp'
#polygon = 'C:/temp/AirLog_CASUR/DATA/Polygon.shp'
wingspan = ancho*0.0002795/31
#titulo = 'Mapa de prueba'
#nombre = 'prueba'

parameters = { 'INPUT' : layer_drift,
            'DISTANCE' : wingspan/2,
            'SEGMENTS' : 5,
            'END_CAP_STYLE' : 2,
            'JOIN_STYLE':0,
            'MITER_LIMIT':2,
            'DISSOLVE' : False,
            'OUTPUT' : 'TEMPORARY_OUTPUT' }
temp1 = processing.run('qgis:buffer', parameters)


parameters = { 'ID' : 'TYPE',
            'INTERSECT' : 'TEMPORARY_OUTPUT',
            'POLYGONS' : temp1 ['OUTPUT'] }
temp2 = processing.run('saga:polygonselfintersection', parameters)


parameters = { 'INPUT' : temp2 ['INTERSECT'],
            'OUTPUT' : 'TEMPORARY_OUTPUT' }
temp3 = processing.run('qgis:fixgeometries', parameters)


parameters = { 'INPUT' : temp3 ['OUTPUT'],
            'OVERLAY' : layer_polygon,
            'OVERLAY_FIELDS_PREFIX' : '',
            'OUTPUT' : 'TEMPORARY_OUTPUT', }
temp4 = processing.run('qgis:union', parameters)

pr = temp4 ['OUTPUT'].dataProvider()
pr.addAttributes([QgsField("Resultado", QVariant.String),
                  QgsField("Area_m2",  QVariant.Double)])
temp4 ['OUTPUT'].updateFields()


##SELECCION "AREA SIN APLICAR"
temp4 ['OUTPUT'].selectByExpression('"TYPE" is NULL and "TYPE_2"= \'SPRAY_AREA\'', QgsVectorLayer.SetSelection)

features = temp4 ['OUTPUT'].selectedFeatures()

result = "Area sin Aplicar"
for f in features:
    id=f.id()
    attr_value = {pr.fieldNameIndex('Resultado'):result}
    pr.changeAttributeValues({id:attr_value})
temp4 ['OUTPUT'].commitChanges()
temp4 ['OUTPUT'].removeSelection()


##SELECCION "TRASLAPES"
temp4 ['OUTPUT'].selectByExpression('"ID_1"> \'SPRAY_ON\' and "TYPE_2"= \'SPRAY_AREA\'', QgsVectorLayer.SetSelection)

features = temp4 ['OUTPUT'].selectedFeatures()

result = "Traslapado"
for f in features:
    id=f.id()
    attr_value = {pr.fieldNameIndex('Resultado'):result}
    pr.changeAttributeValues({id:attr_value})
temp4 ['OUTPUT'].commitChanges()
temp4 ['OUTPUT'].removeSelection()


##SELECCION "APLICACION CORRECTA"
temp4 ['OUTPUT'].selectByExpression('"TYPE"= \'SPRAY_ON\' and "ID_1"= \'SPRAY_ON\' and "TYPE_2"= \'SPRAY_AREA\'', QgsVectorLayer.SetSelection)

features = temp4 ['OUTPUT'].selectedFeatures()

result = "Aplicación Correcta"
for f in features:
    id=f.id()
    attr_value = {pr.fieldNameIndex('Resultado'):result}
    pr.changeAttributeValues({id:attr_value})
temp4 ['OUTPUT'].commitChanges()
temp4 ['OUTPUT'].removeSelection()


##SELECCION "FUERA DE AREA"
temp4 ['OUTPUT'].selectByExpression('"TYPE">=\'SPRAY_ON\' and "TYPE_2" is NULL', QgsVectorLayer.SetSelection)

features = temp4 ['OUTPUT'].selectedFeatures()

result = "Fuera de Area"
for f in features:
    id=f.id()
    attr_value = {pr.fieldNameIndex('Resultado'):result}
    pr.changeAttributeValues({id:attr_value})
temp4 ['OUTPUT'].commitChanges()
temp4 ['OUTPUT'].removeSelection()


##CALCULO DE AREA GENERAL

features = temp4 ['OUTPUT'].getFeatures()

for f in features:
    id=f.id()
    calculator = QgsDistanceArea()
    calculator.setEllipsoid('WGS84')
    geom = f.geometry()
    area = calculator.measureArea(geom)
    attr_value = {pr.fieldNameIndex('Area_m2'):area}
    pr.changeAttributeValues({id:attr_value})
temp4 ['OUTPUT'].commitChanges()


##CALCULO DE AREA POR RESULTADO

temp4 ['OUTPUT'].selectByExpression('"Resultado"= \'Area sin Aplicar\'', QgsVectorLayer.SetSelection)
features = temp4 ['OUTPUT'].selectedFeatures()
area_asa = 0
for f in features:
    area_asa = f["Area_m2"] + area_asa
area_asa = round((area_asa/10000),2)
print ('area_asa :' + str(area_asa))

temp4 ['OUTPUT'].selectByExpression('"Resultado"= \'Traslapado\'', QgsVectorLayer.SetSelection)
features = temp4 ['OUTPUT'].selectedFeatures()
area_tra = 0
for f in features:
    area_tra = f["Area_m2"] + area_tra
area_tra = round((area_tra/10000),2)
print ('area_tra :' + str(area_tra))

temp4 ['OUTPUT'].selectByExpression('"Resultado"= \'Aplicación Correcta\'', QgsVectorLayer.SetSelection)
features = temp4 ['OUTPUT'].selectedFeatures()
area_cor = 0
for f in features:
    area_cor = f["Area_m2"] + area_cor
area_cor = round((area_cor/10000),2)
print ('area_cor :' + str(area_cor))

temp4 ['OUTPUT'].selectByExpression('"Resultado"= \'Fuera de Area\'', QgsVectorLayer.SetSelection)
features = temp4 ['OUTPUT'].selectedFeatures()
area_fue = 0
for f in features:
    area_fue = f["Area_m2"] + area_fue
area_fue = round((area_fue/10000),2)
print ('area_fue :' + str(area_fue))

area_tot = round((area_asa + area_tra + area_cor + area_fue),2)
print ('area_total :' + str(area_tot))
area_tot_poly = round((area_asa + area_tra + area_cor),2)
print ('area_total_poly :' + str(area_tot_poly))

porc_asa = round((area_asa*100/area_tot),2)
print ('porc_asa :' + str(porc_asa) + '%')
porc_tra = round((area_tra*100/area_tot),2)
print ('porc_tra :' + str(porc_tra) + '%')
porc_cor = round((area_cor*100/area_tot),2)
print ('porc_cor :' + str(porc_cor) + '%')
porc_fue = round((area_fue*100/area_tot),2)
print ('porc_fue :' + str(porc_fue) + '%')
porc_tot = round((porc_asa + porc_tra + porc_cor + porc_fue),1)

porc_asa_poly = round((area_asa*100/area_tot_poly),2)
print ('porc_asa_poly :' + str(porc_asa) + '%')
porc_tra_poly = round((area_tra*100/area_tot_poly),2)
print ('porc_tra_poly :' + str(porc_tra) + '%')
porc_cor_poly = round((area_cor*100/area_tot_poly),2)
print ('porc_cor_poly :' + str(porc_cor) + '%')
#porc_fue_poly = round((area_fue*100/area_poly),2)
#print ('porc_fue_poly :' + str(porc_fue) + '%')
porc_tot_poly = round((porc_asa_poly + porc_tra_poly + porc_cor_poly),1)


ruta = QgsProject.instance().readPath("./")

root = QgsProject.instance().layerTreeRoot()

root.insertLayer(0, temp4 ['OUTPUT'])
temp4 ['OUTPUT'].loadNamedStyle(ruta + '/Procesamiento/resultado.qml')

temp4 ['OUTPUT'].removeSelection()

# Move Layer
myalayer = root.findLayer(layer_polygon.id())
myClone = myalayer.clone()
parent = myalayer.parent()
parent.insertChildNode(0, myClone)
parent.removeChildNode(myalayer)
layer_polygon.loadNamedStyle(ruta + '/Procesamiento/polygon.qml')



##PRODUCCION DE MAPA

mapcanvas = iface.mapCanvas()
layoutmanager = QgsProject.instance().layoutManager()
layout = layoutmanager.layoutByName("Mapa")
map = layout.referenceMap()



#ETIQUETAS

label = layout.itemById('titulo')
label.setText(titulo)
label = layout.itemById('nombre')
label.setText(nombre)
label = layout.itemById('fecha')
label.setText(fecha.toString())
label = layout.itemById('hora')
label.setText(hora.toString())
label = layout.itemById('variedad')
label.setText(variedad)
label = layout.itemById('tch')
label.setText(tch)
label = layout.itemById('ncortes')
label.setText(ncortes)
label = layout.itemById('velocidad')
label.setText(velocidad)
label = layout.itemById('viento')
label.setText(viento)
label = layout.itemById('humedad')
label.setText(humedad)
label = layout.itemById('temperatura')
label.setText(temperatura)
label = layout.itemById('producto1')
label.setText(producto1)
label = layout.itemById('producto2')
label.setText(producto2)
label = layout.itemById('producto3')
label.setText(producto3)
label = layout.itemById('um1')
label.setText(um1)
label = layout.itemById('um2')
label.setText(um2)
label = layout.itemById('um3')
label.setText(um3)
label = layout.itemById('dosis1')
label.setText(dosis1)
label = layout.itemById('dosis2')
label.setText(dosis2)
label = layout.itemById('dosis3')
label.setText(dosis3)



#Areas y Porcen Con base a Area del lote

label = layout.itemById('area_cor_poly')
label.setText(str(area_cor))
label = layout.itemById('area_asa_poly')
label.setText(str(area_asa))
label = layout.itemById('area_fue_poly')
label.setText('***')
label = layout.itemById('area_tra_poly')
label.setText(str(area_tra))
label = layout.itemById('porc_cor_poly')
label.setText(str(porc_cor_poly))
label = layout.itemById('porc_asa_poly')
label.setText(str(porc_asa_poly))
label = layout.itemById('porc_tra_poly')
label.setText(str(porc_tra_poly))
label = layout.itemById('porc_fue_poly')
label.setText('***')
label = layout.itemById('area_tot_poly')
label.setText(str(area_tot_poly))
label = layout.itemById('porc_tot_poly')
label.setText(str(porc_tot_poly))


#Areas y Porcen Con base a Area de Aplicacion

label = layout.itemById('area_cor')
label.setText(str(area_cor))
label = layout.itemById('area_asa')
label.setText(str(area_asa))
label = layout.itemById('area_fue')
label.setText(str(area_fue))
label = layout.itemById('area_tra')
label.setText(str(area_tra))
label = layout.itemById('porc_cor')
label.setText(str(porc_cor))
label = layout.itemById('porc_asa')
label.setText(str(porc_asa))
label = layout.itemById('porc_fue')
label.setText(str(porc_fue))
label = layout.itemById('porc_tra')
label.setText(str(porc_tra))
label = layout.itemById('area_tot')
label.setText(str(area_tot))
label = layout.itemById('porc_tot')
label.setText(str(porc_tot))

box = temp4 ['OUTPUT'].extent()
mapcanvas.setExtent(box)
map.zoomToExtent(box)
exporter = QgsLayoutExporter(layout)
exporter.exportToPdf(ruta + "/MAPAS/" + nombre + ".pdf", QgsLayoutExporter.PdfExportSettings() )
 
root.removeLayer(temp4 ['OUTPUT'])
 
QMessageBox.information(iface.mainWindow(), "Finalizado", 'El mapas ha sido guardado en la ruta: '+ruta+"/MAPAS/" + nombre + '.pdf')


